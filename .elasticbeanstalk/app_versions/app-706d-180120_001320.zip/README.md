# SpartaHack2018
Repo for spartahack 2018 (Project to be Determined)
